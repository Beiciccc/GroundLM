# Supplementary Material (anonymized for review)

Code, constructed data, and result artifacts for the submission
"Grounding or Lexical Overlap? A Matched-Pair Study of Internals-Based
Faithfulness Probes". All experiments are API-free and run on a single
A100-40G GPU (analysis/figures run on CPU).

## Layout
- `src/groundlm/` — package: matched-pair construction, probing/directions,
  confidence purge, cross-family Procrustes transfer, conformal gate, NLI baselines.
- `scripts/` — build datasets, extract activations, and reproduce every reported
  number (C1 within-stratum, C3 cross-family alignment + held-out control, C4 RAGTruth).
- `data/*.jsonl` — the constructed Support x Overlap statements (derived from NQ-Swap).
- `runs/*.json`, `runs/*/report_*.json`, `runs/*/features.meta.json` — the producer
  outputs behind each table/figure (the large cached activation `.npz` are omitted for
  size; regenerate with `reproduce.sh extract`).
- `reproduce.sh` — end-to-end driver (build -> extract -> analyze).
- `requirements.txt` — pinned dependencies.

## Reproduce
    pip install -r requirements.txt
    bash reproduce.sh            # see the file for per-stage targets
GPU extraction needs the open-weight model families (Llama-3.1-8B, Qwen2.5-7B,
Mistral-7B-v0.3, Gemma-2-9B) from their public releases. If huggingface.co is
unreachable, set HF_ENDPOINT to a mirror.

Full code, cached features, and datasets will be released upon acceptance.
